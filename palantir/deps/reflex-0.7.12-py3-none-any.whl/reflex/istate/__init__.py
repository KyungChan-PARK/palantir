"""This module will provide interfaces for the state."""
