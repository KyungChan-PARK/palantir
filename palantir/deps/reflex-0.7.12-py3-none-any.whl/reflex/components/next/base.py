"""Base for NextJS components."""

from reflex.components.component import Component


class NextComponent(Component):
    """A Component used as based for any NextJS component."""

    ...
