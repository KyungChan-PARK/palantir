from weaviate.debug.types import DebugRESTObject

__all__ = [
    "DebugRESTObject",
]
